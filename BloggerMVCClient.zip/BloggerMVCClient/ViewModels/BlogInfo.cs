﻿using BloggerMVCClient.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BloggerMVCClient.ViewModels
{
    public class BlogInfo
    {
        public Blog Blog { get; set; }
        public IEnumerable<BlogPost> Posts { get; set; }
    }
}
