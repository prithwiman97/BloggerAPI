﻿using BloggerMVCClient.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BloggerMVCClient.ViewModels
{
    public class PostInfo
    {
        public string Username { get; set; }
        public BlogPost Post { get; set; }
        public IEnumerable<Comment> Comments { get; set; }
    }
}
