﻿using BloggerMVCClient.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BloggerMVCClient.ViewModels
{
    public class BloggerViewModel
    {
        public Users User { get; set; }
        public IEnumerable<Blog> Blogs { get; set; }
    }
}
