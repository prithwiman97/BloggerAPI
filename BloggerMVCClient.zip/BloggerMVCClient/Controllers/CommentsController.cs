﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using BloggerMVCClient.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace BloggerMVCClient.Controllers
{
    public class CommentsController : Controller
    {
        Uri baseAddress = new Uri("https://localhost:44386/api");
        HttpClient client;
        public CommentsController()
        {
            client = new HttpClient();
            client.BaseAddress = baseAddress;
        }
        public IActionResult Create(Comment comment)
        {
            string data = JsonConvert.SerializeObject(comment);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = client.PostAsync(client.BaseAddress + "/Comments", content).Result;
            if (response.IsSuccessStatusCode)
                return RedirectToAction("Post", "BlogPosts", new { blogPostId = comment.PostId });
            return View();
        }
        public IActionResult Delete(int commentId,int postId)
        {
            HttpResponseMessage response = client.DeleteAsync(client.BaseAddress + "/Comments/"+commentId).Result;
            if (response.IsSuccessStatusCode)
                return RedirectToAction("Post", "BlogPosts", new { blogPostId = postId });
            return View();
        }
    }
}
