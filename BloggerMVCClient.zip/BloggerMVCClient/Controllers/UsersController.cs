﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using BloggerMVCClient.Models;
using BloggerMVCClient.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace BloggerMVCClient.Controllers
{
    public class UsersController : Controller
    {
        Uri baseAddress = new Uri("https://localhost:44386/api");
        HttpClient client;
        public UsersController()
        {
            client = new HttpClient();
            client.BaseAddress = baseAddress;
        }
        public IActionResult MyBlogger(string username)
        {
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/Users/"+username).Result;
            if(response.IsSuccessStatusCode)
            {
                Users user;
                IEnumerable<Blog> blogs;
                string data = response.Content.ReadAsStringAsync().Result;
                user = JsonConvert.DeserializeObject<Users>(data);
                response = client.GetAsync(client.BaseAddress + "/Blogs").Result;
                data = response.Content.ReadAsStringAsync().Result;
                blogs = JsonConvert.DeserializeObject<List<Blog>>(data);
                blogs = from b in blogs where b.Username == username select b;
                BloggerViewModel viewModel = new BloggerViewModel
                {
                    User = user,
                    Blogs = blogs
                };
                return View(viewModel);
            }
            return View();
        }
        public IActionResult New()
        {
            return View();
        }
        
        [HttpPost]
        public IActionResult Create(Users user)
        {
            string userData = JsonConvert.SerializeObject(user);
            StringContent content = new StringContent(userData, Encoding.UTF8, "application/json");
            HttpResponseMessage response = client.PostAsync(client.BaseAddress + "/Users", content).Result;
            if (response.IsSuccessStatusCode)
                return RedirectToAction("MyBlogger",new { username=user.Username });
            return View("New");
        }

        public IActionResult Edit(string username)
        {
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/Users/" + username).Result;
            if (response.IsSuccessStatusCode)
            {
                Users user;
                string data = response.Content.ReadAsStringAsync().Result;
                user = JsonConvert.DeserializeObject<Users>(data);
                return View(user);
            }
            return View();
        }


        [HttpPost]
        public IActionResult Update(Users user)
        {
            string userData = JsonConvert.SerializeObject(user);
            StringContent content = new StringContent(userData, Encoding.UTF8, "application/json");
            HttpResponseMessage response = client.PutAsync(client.BaseAddress + "/Users/"+user.Username, content).Result;
            if (response.IsSuccessStatusCode)
                return RedirectToAction("MyBlogger",new { username=user.Username });
            return RedirectToAction("Edit", new { username = user.Username });
        }
        public IActionResult Login()
        {
            return View();
        }
        public IActionResult Auth(Users user)
        {
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/Users/" + user.Username).Result;
            if (response.IsSuccessStatusCode)
            {
                Users authUser;
                string data = response.Content.ReadAsStringAsync().Result;
                authUser = JsonConvert.DeserializeObject<Users>(data);
                if(authUser!=null && authUser.Password == user.Password)
                {
                    return RedirectToAction("MyBlogger", new { username = authUser.Username });
                }
                return View("Login");
            }
            return View("Login");
        }
    }
}
