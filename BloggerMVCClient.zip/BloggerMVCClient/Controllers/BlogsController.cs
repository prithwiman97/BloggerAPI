﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using BloggerMVCClient.Models;
using BloggerMVCClient.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace BloggerMVCClient.Controllers
{
    public class BlogsController : Controller
    {
        Uri baseAddress = new Uri("https://localhost:44386/api");
        HttpClient client;
        public BlogsController()
        {
            client = new HttpClient();
            client.BaseAddress = baseAddress;
        }

        public IActionResult Blog(int blogId)
        {
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/Blogs/" + blogId).Result;
            if (response.IsSuccessStatusCode)
            {
                Blog blog;
                IEnumerable<BlogPost> posts;
                string data = response.Content.ReadAsStringAsync().Result;
                blog = JsonConvert.DeserializeObject<Blog>(data);
                response = client.GetAsync(client.BaseAddress + "/BlogPosts").Result;
                data = response.Content.ReadAsStringAsync().Result;
                posts = JsonConvert.DeserializeObject<List<BlogPost>>(data);
                posts = from p in posts where p.BlogId == blogId select p;
                BlogInfo blogInfo = new BlogInfo
                {
                    Blog = blog,
                    Posts = posts
                };
                return View(blogInfo);
            }
            return View();
        }
        public IActionResult New(string username)
        {
            Blog blog = new Blog { Username = username };
            return View(blog);
        }
        public IActionResult Create(Blog blog)
        {
            string data = JsonConvert.SerializeObject(blog);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = client.PostAsync(client.BaseAddress + "/Blogs", content).Result;
            if (response.IsSuccessStatusCode)
                return RedirectToAction("MyBlogger","Users", new { username = blog.Username });
            return View();
        }

        public IActionResult Edit(int blogId)
        {
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/Blogs/" + blogId).Result;
            if (response.IsSuccessStatusCode)
            {
                Blog blog;
                string data = response.Content.ReadAsStringAsync().Result;
                blog = JsonConvert.DeserializeObject<Blog>(data);
                return View(blog);
            }
            return View();
        }
        public IActionResult Update(Blog blog)
        {
            string data = JsonConvert.SerializeObject(blog);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = client.PutAsync(client.BaseAddress + "/Blogs/"+blog.Id, content).Result;
            if (response.IsSuccessStatusCode)
                return RedirectToAction("Blog", new { blogId = blog.Id });
            return View();
        }
    }
}
