﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using BloggerMVCClient.Models;
using BloggerMVCClient.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace BloggerMVCClient.Controllers
{
    public class BlogPostsController : Controller
    {
        Uri baseAddress = new Uri("https://localhost:44386/api");
        HttpClient client;
        public BlogPostsController()
        {
            client = new HttpClient();
            client.BaseAddress = baseAddress;
        }
        public IActionResult Post(int blogPostId,string username)
        {
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/BlogPosts/" + blogPostId).Result;
            if(response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                BlogPost post = JsonConvert.DeserializeObject<BlogPost>(data);
                response = client.GetAsync(client.BaseAddress + "/Comments/" + blogPostId).Result;
                data = response.Content.ReadAsStringAsync().Result;
                List<Comment> comments = JsonConvert.DeserializeObject<List<Comment>>(data);
                PostInfo postInfo = new PostInfo
                {
                    Username = username,
                    Post = post,
                    Comments = comments
                };
                return View(postInfo);
            }
            return View();
        }
        public IActionResult New(int blogId)
        {
            BlogPost post = new BlogPost { BlogId = blogId };
            return View(post);
        }
        public IActionResult Create(BlogPost post)
        {
            string data = JsonConvert.SerializeObject(post);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = client.PostAsync(client.BaseAddress + "/BlogPosts", content).Result;
            if (response.IsSuccessStatusCode)
                return RedirectToAction("Blog", "Blogs", new { blogId = post.BlogId });
            return View();
        }
        public IActionResult Edit(int blogPostId)
        {
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/BlogPosts/" + blogPostId).Result;
            if (response.IsSuccessStatusCode)
            {
                BlogPost post;
                string data = response.Content.ReadAsStringAsync().Result;
                post = JsonConvert.DeserializeObject<BlogPost>(data);
                return View(post);
            }
            return View();
        }
        public IActionResult Update(BlogPost post)
        {
            string data = JsonConvert.SerializeObject(post);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = client.PutAsync(client.BaseAddress + "/BlogPosts/" + post.Id, content).Result;
            if (response.IsSuccessStatusCode)
                return RedirectToAction("Blog","Blogs", new { blogId = post.BlogId });
            return View();
        }
    }
}
